#!/usr/bin/env bash
# 部署脚本公共函数（pack / install 共用）

set -euo pipefail

log() {
  echo "[$(date +%H:%M:%S)] $*"
}

die() {
  echo "错误: $*" >&2
  exit 1
}

require_cmd() {
  for c in "$@"; do
    command -v "$c" >/dev/null 2>&1 || die "缺少命令: $c"
  done
}

# 从 .env 读取 DATABASE_URL（简单解析，支持常见 postgresql URL）
load_database_url_from_env() {
  local env_file="$1"
  [[ -f "$env_file" ]] || die "环境文件不存在: $env_file"

  local line url
  line="$(grep -E '^[[:space:]]*DATABASE_URL=' "$env_file" | tail -n1 || true)"
  [[ -n "$line" ]] || die "$env_file 中未找到 DATABASE_URL"

  url="${line#DATABASE_URL=}"
  url="${url#\"}"
  url="${url%\"}"
  url="${url#\'}"
  url="${url%\'}"

  parse_postgres_url "$url"
}

parse_postgres_url() {
  local url="$1"
  if [[ ! "$url" =~ ^postgres(ql)?:// ]]; then
    die "无法解析 DATABASE_URL（需 postgresql:// 格式）"
  fi

  # postgresql://user:pass@host:port/db?schema=public
  local rest="${url#*://}"
  local userpass="${rest%%@*}"
  local hostpart="${rest#*@}"
  local hostport="${hostpart%%/*}"
  local dbquery="${hostpart#*/}"
  PGDATABASE="${dbquery%%\?*}"

  PGUSER="${userpass%%:*}"
  local pass="${userpass#*:}"
  if [[ "$pass" == "$userpass" ]]; then
    PGPASSWORD=""
  else
    PGPASSWORD="$pass"
  fi
  export PGPASSWORD

  if [[ "$hostport" == *:* ]]; then
    PGHOST="${hostport%%:*}"
    PGPORT="${hostport#*:}"
  else
    PGHOST="$hostport"
    PGPORT="5432"
  fi

  export PGHOST PGPORT PGUSER PGDATABASE
  PGDUMP_OPTS=(-h "$PGHOST" -p "$PGPORT" -U "$PGUSER")
}

# 国内镜像（npm / pnpm / Prisma 二进制）
apply_china_registry() {
  export NPM_CONFIG_REGISTRY="${NPM_CONFIG_REGISTRY:-https://registry.npmmirror.com}"
  export PNPM_HOME="${PNPM_HOME:-$HOME/.local/share/pnpm}"
  export PATH="$PNPM_HOME:$PATH"

  if command -v pnpm >/dev/null 2>&1; then
    pnpm config set registry "$NPM_CONFIG_REGISTRY" >/dev/null
  fi
  if command -v npm >/dev/null 2>&1; then
    npm config set registry "$NPM_CONFIG_REGISTRY" >/dev/null
  fi

  # Prisma 引擎下载镜像（国内服务器建议设置）
  export PRISMA_ENGINES_MIRROR="${PRISMA_ENGINES_MIRROR:-https://registry.npmmirror.com/-/binary/prisma}"

  log "已设置 npm 镜像: $NPM_CONFIG_REGISTRY"
  log "已设置 Prisma 引擎镜像: $PRISMA_ENGINES_MIRROR"
}

ensure_pnpm() {
  apply_china_registry
  if command -v pnpm >/dev/null 2>&1; then
    return 0
  fi
  if command -v corepack >/dev/null 2>&1; then
    log "通过 corepack 启用 pnpm"
    corepack enable
    corepack prepare pnpm@9 --activate
    return 0
  fi
  die "未安装 pnpm。请先安装 Node.js 20+ 并执行: corepack enable && corepack prepare pnpm@9 --activate"
}

ensure_node_version() {
  local min_major=18
  if ! command -v node >/dev/null 2>&1; then
    die "未安装 Node.js（需要 >= ${min_major}，推荐 20 LTS）"
  fi
  local major
  major="$(node -p "process.versions.node.split('.')[0]")"
  if [[ "$major" -lt "$min_major" ]]; then
    die "Node.js 版本过低: $(node -v)，需要 >= v${min_major}"
  fi
  log "Node $(node -v) / $(command -v node)"
}
