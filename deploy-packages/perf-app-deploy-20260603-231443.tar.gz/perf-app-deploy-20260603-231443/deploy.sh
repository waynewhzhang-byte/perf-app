#!/usr/bin/env bash
# deploy.sh — 一键部署入口（位于解压后的 bundle 根目录）
# 用法: sudo ./deploy.sh [选项]
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
exec bash "${SCRIPT_DIR}/source/scripts/deploy/install-on-server.sh" --bundle-dir "$SCRIPT_DIR" "$@"
